import os
for i in range(1,200):
	print("Done" ,i)
	os.system("mkdir "+"dabba"+str(i))
	os.system("echo 'Keep Trying.... '> dabba"+str(i)+"/flag.txt")
	os.system("zip dabba"+str(i)+" dabba"+str(i)+"/*")
	os.system("rm -r dabba"+str(i))